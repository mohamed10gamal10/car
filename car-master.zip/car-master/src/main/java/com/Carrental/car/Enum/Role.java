package com.Carrental.car.Enum;

public enum Role {
    USER,
    ADMIN
}
